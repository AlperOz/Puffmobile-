package com.alper.puf

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val YT_MUSIC = "com.google.android.apps.youtube.music"

fun openInYouTubeMusic(ctx: Context, item: LinkItem) {
    val uri = Uri.parse("https://music.youtube.com/watch?v=${item.videoId}")
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(YT_MUSIC).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "YouTube Music yüklü değil, tarayıcıda açılıyor", Toast.LENGTH_SHORT).show()
        ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private enum class Sheet { None, Save, Audio, Stats }

@Composable
fun KoleksiyonScreen(store: Store, shared: String?, onSharedUsed: () -> Unit, onWatch: (LinkItem) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("all") }
    var sheet by remember { mutableStateOf(Sheet.None) }
    var draftTitle by remember { mutableStateOf("") }
    var draftCat by remember { mutableStateOf("lofi") }
    var draftUrl by remember { mutableStateOf("") }
    var audioItem by remember { mutableStateOf<LinkItem?>(null) }

    fun startSave(raw: String) {
        val u = firstUrl(raw) ?: raw.trim()
        if (YouTubeIds.extract(u) == null) {
            Toast.makeText(ctx, "Bu bir YouTube video linkine benzemiyor", Toast.LENGTH_SHORT).show()
            return
        }
        draftUrl = u
        draftTitle = ""
        draftCat = if (cat == "all") "lofi" else cat
        sheet = Sheet.Save
        scope.launch { fetchTitle(u)?.let { if (draftTitle.isBlank()) draftTitle = it } }
    }

    LaunchedEffect(shared) {
        if (shared != null) {
            startSave(shared)
            onSharedUsed()
        }
    }

    fun audio(item: LinkItem) {
        if (store.dontShowAudioTip) {
            store.countHandoff(); openInYouTubeMusic(ctx, item)
        } else {
            audioItem = item; sheet = Sheet.Audio
        }
    }

    val shown = store.items.filter { cat == "all" || it.cat == cat }

    Box(Modifier.fillMaxSize().background(C.Mint)) {
        LazyColumn(
            Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.ic_head), null, Modifier.size(44.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("puf", style = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Black, color = C.Yellow))
                    }
                    Spacer(Modifier.weight(1f))
                    Row(
                        Modifier
                            .shadow(6.dp, RoundedCornerShape(20.dp))
                            .background(Color.White, RoundedCornerShape(20.dp))
                            .clickable { sheet = Sheet.Stats }
                            .padding(start = 6.dp, end = 12.dp, top = 5.dp, bottom = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(26.dp).balloon(YellowStops, CircleShape, 2.dp, gloss = false))
                        Spacer(Modifier.width(8.dp))
                        Text("${formatMb(store.totalBytes)} · ${formatTime(store.totalSec)}",
                            style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = C.Green))
                    }
                }
            }
            item {
                Column {
                    Text("Koleksiyon", style = H1)
                    Text("Linkleri kaydet, kategorile, istediğin gibi dinle.", style = Body)
                }
            }
            item {
                Row(
                    Modifier.fillMaxWidth().height(54.dp).background(Color.White, RoundedCornerShape(27.dp))
                        .padding(start = 18.dp, end = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.weight(1f)) {
                        if (url.isEmpty()) Text("YouTube linkini yapıştır", style = Body.copy(fontSize = 14.sp))
                        BasicTextField(url, { url = it }, singleLine = true,
                            textStyle = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = C.Ink),
                            modifier = Modifier.fillMaxWidth())
                    }
                    BalloonButton("Kaydet", stops = GreenStops, textColor = Color.White, height = 40.dp,
                        onClick = { startSave(url); url = "" })
                }
            }
            item { CategoryRail(cat) { cat = it } }
            if (shown.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth().padding(top = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        PopIcon(R.drawable.ic_head, 150.dp, 120.dp, 130.dp, corner = 60.dp)
                        Spacer(Modifier.height(16.dp))
                        Text("Henüz link yok", style = Strong.copy(fontSize = 17.sp))
                        Text("YouTube'da Paylaş → puf'a kaydet de,\nya da linki yukarı yapıştır.", style = Body,
                            modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
            items(shown, key = { it.id }) { item ->
                LinkCard(item, onWatch = { onWatch(item) }, onAudio = { audio(item) }, onDelete = { store.remove(item.id) })
            }
        }

        when (sheet) {
            Sheet.Save -> BottomSheet(onDismiss = { sheet = Sheet.None }) {
                Text("Nereye kaydedelim?", style = H2)
                Text(draftUrl, style = Body, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(12.dp))
                Text("Başlık", style = Strong.copy(fontSize = 13.sp))
                Box(Modifier.padding(top = 6.dp).fillMaxWidth().height(48.dp).background(C.Field, RoundedCornerShape(24.dp))
                    .padding(horizontal = 16.dp), contentAlignment = Alignment.CenterStart) {
                    if (draftTitle.isEmpty()) Text("Başlık alınıyor…", style = Body)
                    BasicTextField(draftTitle, { draftTitle = it }, singleLine = true,
                        textStyle = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Bold, color = C.Ink),
                        modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(14.dp))
                Text("Kategori", style = Strong.copy(fontSize = 13.sp))
                Row(Modifier.padding(top = 10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CATS.forEach { c ->
                        val on = c.key == draftCat
                        Column(
                            Modifier.weight(1f)
                                .then(if (on) Modifier.border(3.dp, C.Yellow, RoundedCornerShape(18.dp)) else Modifier)
                                .clickable { draftCat = c.key }.padding(4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            PopIcon(c.icon, 52.dp, 48.dp, 56.dp, corner = 14.dp)
                            Text(c.label, style = Strong.copy(fontSize = 11.sp), modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BalloonButton("Vazgeç", Modifier.weight(1f), stops = WhiteStops, onClick = { sheet = Sheet.None })
                    BalloonButton("Kaydet", Modifier.weight(1.4f), stops = GreenStops, textColor = Color.White, onClick = {
                        val vid = YouTubeIds.extract(draftUrl) ?: return@BalloonButton
                        val newId = System.currentTimeMillis()
                        val savedUrl = draftUrl
                        val needTitle = draftTitle.isBlank()
                        store.add(LinkItem(newId, savedUrl, vid,
                            draftTitle.ifBlank { "YouTube videosu" }, draftCat, newId))
                        if (needTitle) scope.launch { fetchTitle(savedUrl)?.let { store.updateTitle(newId, it) } }
                        cat = draftCat
                        sheet = Sheet.None
                        Toast.makeText(ctx, "${catOf(draftCat).label} kategorisine kaydedildi", Toast.LENGTH_SHORT).show()
                    })
                }
            }
            Sheet.Audio -> BottomSheet(onDismiss = { sheet = Sheet.None }) {
                Text("YouTube Music'te sadece ses", style = H2)
                Text("“${audioItem?.title}” YouTube Music uygulamasında açılacak. Veri tasarrufu ayarı açıksa video yüklenmez.",
                    style = Body, modifier = Modifier.padding(top = 6.dp))
                Column(Modifier.padding(top = 12.dp).fillMaxWidth().background(C.Field, RoundedCornerShape(20.dp)).padding(14.dp)) {
                    Text("Bir kerelik ayar", style = Strong.copy(fontSize = 13.sp))
                    Text("YouTube Music → profil fotoğrafı → Ayarlar → Veri tasarrufu → “Müzik videolarını oynatma” ve “Podcast videolarını oynatma” açık olsun. Müzikte Premium gerekir, podcast'lerde gerekmez.",
                        style = Body.copy(color = C.Ink, fontSize = 12.5.sp))
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                    Checkbox(store.dontShowAudioTip, { store.setDontShow(it) },
                        colors = CheckboxDefaults.colors(checkedColor = C.Green))
                    Text("Bir daha gösterme", style = Body)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 6.dp)) {
                    BalloonButton("Vazgeç", Modifier.weight(1f), stops = WhiteStops, onClick = { sheet = Sheet.None })
                    BalloonButton("YouTube Music'te aç", Modifier.weight(1.6f), onClick = {
                        sheet = Sheet.None
                        audioItem?.let { store.countHandoff(); openInYouTubeMusic(ctx, it) }
                    })
                }
            }
            Sheet.Stats -> StatsSheet(store) { sheet = Sheet.None }
            Sheet.None -> {}
        }
    }
}

@Composable
private fun CategoryRail(selected: String, onPick: (String) -> Unit) {
    val all = listOf("all" to "Tümü") + CATS.map { it.key to it.label }
    Row(
        Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(30.dp))
            .background(Color.White, RoundedCornerShape(30.dp)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        all.forEach { (k, label) ->
            val on = k == selected
            Box(
                Modifier.weight(1f).height(44.dp)
                    .then(if (on) Modifier.balloon(YellowStops, RoundedCornerShape(22.dp), 4.dp) else Modifier)
                    .clickable(remember { MutableInteractionSource() }, null) { onPick(k) },
                contentAlignment = Alignment.Center
            ) {
                Text(label, style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.ExtraBold,
                    color = if (on) C.Ink else C.Mu), maxLines = 1)
            }
        }
    }
}

@Composable
private fun LinkCard(item: LinkItem, onWatch: () -> Unit, onAudio: () -> Unit, onDelete: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().height(80.dp).shadow(6.dp, RoundedCornerShape(24.dp))
            .background(Color.White, RoundedCornerShape(24.dp))
            .clickable { onWatch() }.padding(start = 10.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PopIcon(catOf(item.cat).icon, 58.dp, 56.dp, 64.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, style = Strong, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 3.dp)) {
                Text(catOf(item.cat).label, style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = C.Green),
                    modifier = Modifier.background(C.Chip, RoundedCornerShape(10.dp)).padding(horizontal = 8.dp, vertical = 2.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (confirm) "Silinsin mi?" else "youtube.com",
                    style = Body.copy(fontSize = 12.sp, color = if (confirm) C.Coral else C.Mu),
                    modifier = Modifier.clickable { if (confirm) onDelete() else confirm = true })
            }
        }
        BalloonButton("YT Music", stops = YellowStops, height = 40.dp, onClick = onAudio)
    }
}

@Composable
fun BottomSheet(onDismiss: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0x5A0A1E18))
            .clickable(remember { MutableInteractionSource() }, null) { onDismiss() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            Modifier.fillMaxWidth()
                .background(Color.White, RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                .clickable(remember { MutableInteractionSource() }, null) { }
                .navigationBarsPadding().imePadding()
                .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 22.dp)
        ) {
            Box(Modifier.align(Alignment.CenterHorizontally).size(44.dp, 5.dp).background(Color(0x2E10281F), CircleShape))
            Spacer(Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
fun StatsSheet(store: Store, onDismiss: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    val since = SimpleDateFormat("d MMMM", Locale("tr")).format(Date(store.since))
    BottomSheet(onDismiss) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text("Veri ve süre", style = H2, modifier = Modifier.weight(1f))
            Text("$since tarihinden beri", style = Body.copy(fontSize = 12.sp))
        }
        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("Kullanılan veri", formatMb(store.totalBytes), R.drawable.ic_bolt, Modifier.weight(1f))
            StatTile("İzleme süresi", formatTime(store.totalSec), R.drawable.ic_moon, Modifier.weight(1f))
        }
        Row(Modifier.padding(top = 10.dp).fillMaxWidth().background(C.Field, RoundedCornerShape(16.dp)).padding(12.dp)) {
            Text("YouTube Music'e açılan", style = Strong.copy(fontSize = 13.sp), modifier = Modifier.weight(1f))
            Text("${store.handoffs} kez", style = Strong.copy(fontSize = 13.sp))
        }
        Text("Sayaç yalnızca puf içinde izlerken harcanan veriyi ölçer. YouTube Music'teki kullanım o uygulamanın kendi ayarlarında görünür.",
            style = Body.copy(fontSize = 12.sp), modifier = Modifier.padding(top = 10.dp))
        if (confirm) {
            Text("Sayaçlar sıfırlansın mı? Bu geri alınamaz.", style = Strong.copy(fontSize = 13.sp),
                modifier = Modifier.padding(top = 10.dp).fillMaxWidth().background(Color(0xFFFFF3C4), RoundedCornerShape(16.dp)).padding(12.dp))
        }
        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BalloonButton(if (confirm) "Evet, sıfırla" else "Sıfırla", Modifier.weight(1f), stops = WhiteStops, textColor = C.Coral,
                onClick = { if (confirm) { store.resetStats(); confirm = false } else confirm = true })
            BalloonButton("Tamam", Modifier.weight(1f), stops = GreenStops, textColor = Color.White, onClick = onDismiss)
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, icon: Int, modifier: Modifier) {
    Box(modifier.height(118.dp).grooveTray(RoundedCornerShape(24.dp)).padding(14.dp)) {
        Text(label, style = Strong.copy(fontSize = 12.sp, color = C.Mu))
        Image(painterResource(icon), null, Modifier.align(Alignment.TopEnd).size(46.dp).rotate(10f))
        Text(value, style = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = C.Ink),
            modifier = Modifier.align(Alignment.BottomStart))
    }
}
