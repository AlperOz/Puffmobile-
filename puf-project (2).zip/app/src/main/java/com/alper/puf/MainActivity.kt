package com.alper.puf

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private lateinit var store: Store
    private lateinit var hub: PlayerHub
    private var sharedText by mutableStateOf<String?>(null)
    private var tab by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(applicationContext)
        hub = PlayerHub(applicationContext)
        handleShare(intent)
        setContent {
            PufTheme {
                var watching by remember { mutableStateOf<LinkItem?>(null) }
                var libRefresh by remember { mutableIntStateOf(0) }
                val w = watching
                if (w != null) {
                    IzleScreen(store, w, onBack = { watching = null })
                } else {
                    Column(Modifier.fillMaxSize().background(C.Mint)) {
                        Box(Modifier.weight(1f)) {
                            when (tab) {
                                0 -> KoleksiyonScreen(
                                    store = store,
                                    shared = sharedText,
                                    onSharedUsed = { sharedText = null },
                                    onWatch = {
                                        hub.controller?.pause()
                                        watching = it
                                    }
                                )
                                1 -> DonusturScreen(onDone = { libRefresh++ })
                                2 -> KayitScreen(onRecorded = { libRefresh++ })
                                else -> KutuphaneScreen(hub, libRefresh)
                            }
                        }
                        MiniPlayer(hub, Modifier.padding(bottom = 8.dp))
                        NavBar(tab) { tab = it }
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        hub.connect()
    }

    override fun onStop() {
        hub.release()
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let {
                sharedText = it
                tab = 0
            }
        }
    }
}

@Composable
private fun NavBar(selected: Int, onPick: (Int) -> Unit) {
    val items = listOf(
        Triple("Koleksiyon", R.drawable.ic_moon, 0),
        Triple("Dönüştür", R.drawable.ic_bolt, 1),
        Triple("Kayıt", R.drawable.ic_tape, 2),
        Triple("Kütüphane", R.drawable.ic_head, 3)
    )
    Row(
        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp)
            .shadow(14.dp, RoundedCornerShape(34.dp)).background(Color.White, RoundedCornerShape(34.dp))
            .height(68.dp).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { (label, icon, i) ->
            val on = i == selected
            Column(
                Modifier.weight(1f).height(60.dp)
                    .clickable(remember { MutableInteractionSource() }, null) { onPick(i) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
            ) {
                Box(
                    Modifier.size(width = 48.dp, height = 32.dp)
                        .then(if (on) Modifier.balloon(YellowStops, RoundedCornerShape(16.dp), 3.dp, gloss = false) else Modifier),
                    contentAlignment = Alignment.Center
                ) { Image(painterResource(icon), null, Modifier.size(26.dp)) }
                Text(label, style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = if (on) C.Ink else C.Mu))
                if (on) Box(Modifier.padding(top = 1.dp).size(5.dp).background(C.Yellow, CircleShape))
            }
        }
    }
}
