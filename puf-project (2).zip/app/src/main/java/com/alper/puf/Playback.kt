package com.alper.puf

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionToken
import java.io.File
import androidx.media3.common.C as M3

/** Background player: Media3 shows the lock-screen / notification controls automatically. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(M3.USAGE_MEDIA).setContentType(M3.AUDIO_CONTENT_TYPE_MUSIC).build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}

data class Track(val id: String, val uri: Uri, val title: String, val subtitle: String, val isRecording: Boolean)

/** UI-side handle to the background player. */
class PlayerHub(private val ctx: Context) {
    var controller: MediaController? = null
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var title by mutableStateOf<String?>(null)
        private set
    var subtitle by mutableStateOf("")
        private set

    private val artUri: Uri by lazy {
        val f = File(ctx.cacheDir, "art_tape.png")
        if (!f.exists()) {
            val bmp = BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_tape)
            f.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
        }
        Uri.fromFile(f)
    }

    fun connect() {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(playing: Boolean) {
                    isPlaying = playing
                }

                override fun onMediaMetadataChanged(m: MediaMetadata) {
                    title = m.title?.toString()
                    subtitle = m.artist?.toString() ?: ""
                }
            })
            isPlaying = c.isPlaying
            title = c.mediaMetadata.title?.toString()
        }, ContextCompat.getMainExecutor(ctx))
    }

    fun release() {
        controller?.release()
        controller = null
    }

    fun play(list: List<Track>, index: Int) {
        val c = controller ?: return
        val items = list.map { t ->
            MediaItem.Builder()
                .setMediaId(t.id)
                .setUri(t.uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(t.title)
                        .setArtist(t.subtitle)
                        .setArtworkUri(artUri)
                        .build()
                )
                .build()
        }
        c.setMediaItems(items, index, 0L)
        c.prepare()
        c.play()
    }

    fun toggle() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() {
        controller?.seekToNext()
    }

    fun previous() {
        controller?.seekToPrevious()
    }
}
