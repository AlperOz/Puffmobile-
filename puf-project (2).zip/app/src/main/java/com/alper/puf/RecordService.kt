package com.alper.puf

import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class RecState(
    val recording: Boolean = false,
    val mode: String = MODE_MIC,
    val startedAt: Long = 0L,
    val lastFile: String? = null,
    val error: String? = null
)

const val MODE_MIC = "mic"
const val MODE_CAPTURE = "cap"

fun recordingsDir(ctx: Context): File = File(ctx.filesDir, "recordings").apply { mkdirs() }

/**
 * Records either the microphone (m4a) or the phone's playing audio (wav, Android 10+).
 * Playback capture follows Android's rules: apps that disallow capture (and puf itself,
 * see allowAudioPlaybackCapture=false in the manifest) are recorded as silence.
 */
class RecordService : Service() {
    companion object {
        val state = MutableStateFlow(RecState())
        const val EXTRA_MODE = "mode"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "com.alper.puf.STOP_REC"
        private const val CHANNEL = "puf_rec"
        private const val NOTIF_ID = 71

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, RecordService::class.java).setAction(ACTION_STOP))
        }
    }

    private var recorder: MediaRecorder? = null
    private var projection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var captureThread: Thread? = null
    @Volatile private var capturing = false
    private var file: File? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopRecording()
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (state.value.recording) return START_NOT_STICKY
        val mode = intent?.getStringExtra(EXTRA_MODE) ?: MODE_MIC
        startAsForeground(mode)
        try {
            if (mode == MODE_CAPTURE && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
                @Suppress("DEPRECATION")
                val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
                if (data == null) throw IllegalStateException("İzin verilmedi")
                startCapture(code, data)
            } else {
                startMic()
            }
            state.value = RecState(recording = true, mode = mode, startedAt = System.currentTimeMillis())
        } catch (e: Exception) {
            state.value = RecState(error = "Kayıt başlatılamadı: ${e.message}")
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground(mode: String) {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Ses kaydı", NotificationManager.IMPORTANCE_LOW))
        }
        val stopIntent = android.app.PendingIntent.getService(
            this, 1, Intent(this, RecordService::class.java).setAction(ACTION_STOP),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("puf kayıt yapıyor")
            .setContentText(if (mode == MODE_CAPTURE) "Telefonun sesi kaydediliyor" else "Mikrofon kaydediliyor")
            .setOngoing(true)
            .addAction(0, "Durdur", stopIntent)
            .build()
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (mode == MODE_CAPTURE) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            else ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && mode == MODE_CAPTURE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        } else 0
        ServiceCompat.startForeground(this, NOTIF_ID, notif, type)
    }

    private fun newFile(ext: String): File {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return File(recordingsDir(this), "kayit_$stamp.$ext")
    }

    private fun startMic() {
        val f = newFile("m4a")
        file = f
        val r = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioEncodingBitRate(128_000)
        r.setAudioSamplingRate(44_100)
        r.setOutputFile(f.absolutePath)
        r.prepare()
        r.start()
        recorder = r
    }

    @SuppressLint("MissingPermission")
    private fun startCapture(code: Int, data: Intent) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val mp = mpm.getMediaProjection(code, data) ?: throw IllegalStateException("Ekran sesi izni alınamadı")
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (capturing) stop(this@RecordService)
            }
        }, Handler(Looper.getMainLooper()))
        projection = mp
        val config = AudioPlaybackCaptureConfiguration.Builder(mp)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val rate = 44_100
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(rate)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val ar = AudioRecord.Builder()
            .setAudioFormat(format)
            .setBufferSizeInBytes(min * 4)
            .setAudioPlaybackCaptureConfig(config)
            .build()
        audioRecord = ar
        val f = newFile("wav")
        file = f
        val raf = RandomAccessFile(f, "rw")
        raf.setLength(0)
        raf.write(ByteArray(44))
        capturing = true
        ar.startRecording()
        captureThread = Thread {
            val buf = ByteArray(min * 2)
            var total = 0L
            while (capturing) {
                val n = ar.read(buf, 0, buf.size)
                if (n > 0) {
                    raf.write(buf, 0, n)
                    total += n
                }
            }
            writeWavHeader(raf, total, rate, 2)
            raf.close()
        }.also { it.start() }
    }

    private fun writeWavHeader(raf: RandomAccessFile, dataLen: Long, rate: Int, channels: Int) {
        val byteRate = rate * channels * 2
        val h = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt((36 + dataLen).toInt()); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(channels.toShort())
        h.putInt(rate); h.putInt(byteRate); h.putShort((channels * 2).toShort()); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(dataLen.toInt())
        raf.seek(0)
        raf.write(h.array())
    }

    private fun stopRecording() {
        val was = state.value.recording
        try {
            recorder?.apply { stop(); release() }
        } catch (_: Exception) {
        }
        recorder = null
        if (capturing) {
            capturing = false
            try {
                audioRecord?.stop()
            } catch (_: Exception) {
            }
            captureThread?.join(2000)
            audioRecord?.release()
        }
        audioRecord = null
        captureThread = null
        projection?.stop()
        projection = null
        state.value = RecState(lastFile = if (was) file?.absolutePath else null)
        file = null
    }

    override fun onDestroy() {
        if (state.value.recording) stopRecording()
        super.onDestroy()
    }
}
