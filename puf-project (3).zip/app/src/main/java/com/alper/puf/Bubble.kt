package com.alper.puf

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs

fun lastRecMode(ctx: Context): String =
    ctx.getSharedPreferences("puf", Context.MODE_PRIVATE).getString("recMode", MODE_MIC) ?: MODE_MIC

fun saveRecMode(ctx: Context, mode: String) =
    ctx.getSharedPreferences("puf", Context.MODE_PRIVATE).edit().putString("recMode", mode).apply()

fun canDrawOverlay(ctx: Context) = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(ctx)

/** Floating record bubble that stays on top of other apps (like Shazam's pop-up). */
class BubbleService : Service() {
    companion object {
        val running = MutableStateFlow(false)
        const val ACTION_STOP = "com.alper.puf.STOP_BUBBLE"
        private const val CHANNEL = "puf_bubble"
        private const val NOTIF_ID = 72

        fun start(ctx: Context) = ContextCompat.startForegroundService(ctx, Intent(ctx, BubbleService::class.java))
        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, BubbleService::class.java).setAction(ACTION_STOP))
        }
    }

    private var wm: WindowManager? = null
    private var root: FrameLayout? = null
    private var ring: View? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            removeBubble()
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (root == null) {
            if (!canDrawOverlay(this)) {
                stopSelf(); return START_NOT_STICKY
            }
            addBubble()
            scope.launch {
                RecordService.state.collect { s ->
                    ring?.visibility = if (s.recording) View.VISIBLE else View.GONE
                    root?.scaleX = if (s.recording) 1.08f else 1f
                    root?.scaleY = if (s.recording) 1.08f else 1f
                }
            }
        }
        running.value = true
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Yüzen kayıt butonu", NotificationManager.IMPORTANCE_MIN))
        }
        val stopPi = PendingIntent.getService(
            this, 2, Intent(this, BubbleService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("puf yüzen kayıt butonu açık")
            .setContentText("Dokun: kaydı başlat/durdur · Uzun bas: puf'u aç")
            .setOngoing(true)
            .addAction(0, "Kapat", stopPi)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun addBubble() {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        val size = dp(66)
        val frame = FrameLayout(this)
        val ball = ImageView(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFFFF6C7.toInt(), 0xFFFFD84A.toInt(), 0xFFF2B705.toInt())).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), 0xFFFFFFFF.toInt())
            }
            setImageResource(R.drawable.ic_tape)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(9), dp(9), dp(9), dp(9))
            elevation = dp(8).toFloat()
        }
        val r = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(4), 0xFFE5484D.toInt())
            }
            visibility = View.GONE
            elevation = dp(9).toFloat()
        }
        frame.addView(ball, FrameLayout.LayoutParams(size, size))
        frame.addView(r, FrameLayout.LayoutParams(size, size))
        ring = r

        @Suppress("DEPRECATION")
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - size - dp(12)
            y = resources.displayMetrics.heightPixels / 3
        }

        val handler = Handler(Looper.getMainLooper())
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var moved = false; var longFired = false
        val longPress = Runnable {
            longFired = true
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        }
        frame.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y
                    moved = false; longFired = false
                    handler.postDelayed(longPress, 600)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) {
                        moved = true; handler.removeCallbacks(longPress)
                    }
                    if (moved) {
                        lp.x = startX + dx.toInt(); lp.y = startY + dy.toInt()
                        w.updateViewLayout(frame, lp)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    if (!moved && !longFired && e.action == MotionEvent.ACTION_UP) onTap()
                }
            }
            true
        }
        w.addView(frame, lp)
        root = frame
    }

    private fun onTap() {
        if (RecordService.state.value.recording) {
            RecordService.stop(this)
            Toast.makeText(this, "Kayıt durdu · Kütüphane'de", Toast.LENGTH_SHORT).show()
        } else {
            startActivity(Intent(this, RecordTrampoline::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun removeBubble() {
        root?.let { v -> try { wm?.removeView(v) } catch (_: Exception) { } }
        root = null; ring = null
    }

    override fun onDestroy() {
        removeBubble()
        scope.cancel()
        running.value = false
        super.onDestroy()
    }
}

/** Invisible activity: asks for the needed permission/consent, starts recording, closes itself. */
class RecordTrampoline : ComponentActivity() {
    private val projection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK && res.data != null) {
            ContextCompat.startForegroundService(this, Intent(this, RecordService::class.java).apply {
                putExtra(RecordService.EXTRA_MODE, MODE_CAPTURE)
                putExtra(RecordService.EXTRA_CODE, res.resultCode)
                putExtra(RecordService.EXTRA_DATA, res.data)
            })
            Toast.makeText(this, "Telefonun sesi kaydediliyor", Toast.LENGTH_SHORT).show()
        }
        finish()
    }

    private val mic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) begin() else {
            Toast.makeText(this, "Kayıt için mikrofon izni gerekli", Toast.LENGTH_SHORT).show(); finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            mic.launch(Manifest.permission.RECORD_AUDIO)
        } else begin()
    }

    private fun begin() {
        if (lastRecMode(this) == MODE_CAPTURE && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            projection.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
        } else {
            ContextCompat.startForegroundService(this, Intent(this, RecordService::class.java).putExtra(RecordService.EXTRA_MODE, MODE_MIC))
            Toast.makeText(this, "Mikrofon kaydediliyor", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
