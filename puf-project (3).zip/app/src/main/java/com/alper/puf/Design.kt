package com.alper.puf

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Shadow as TextShadow

/** Mint ground with soft blurred blobs, like the design canvas. */
fun Modifier.pufBackground(): Modifier = this.drawBehind {
    drawRect(C.Mint)
    drawCircle(
        Brush.radialGradient(listOf(Color(0x99C3EAD9), Color(0x00C3EAD9)), center = Offset(size.width * 0.15f, size.height * 0.12f), radius = size.width * 0.8f),
        radius = size.width * 0.8f, center = Offset(size.width * 0.15f, size.height * 0.12f)
    )
    drawCircle(
        Brush.radialGradient(listOf(Color(0x88FFF0B0), Color(0x00FFF0B0)), center = Offset(size.width * 0.95f, size.height * 0.55f), radius = size.width * 0.75f),
        radius = size.width * 0.75f, center = Offset(size.width * 0.95f, size.height * 0.55f)
    )
    drawCircle(
        Brush.radialGradient(listOf(Color(0x77B8E5D3), Color(0x00B8E5D3)), center = Offset(size.width * 0.1f, size.height * 0.95f), radius = size.width * 0.7f),
        radius = size.width * 0.7f, center = Offset(size.width * 0.1f, size.height * 0.95f)
    )
}

/** "puf" wordmark wearing the inflatable headphones. */
@Composable
fun PufLogo(modifier: Modifier = Modifier) {
    Box(modifier.size(118.dp, 63.dp)) {
        Image(painterResource(R.drawable.logo_hp), contentDescription = "puf", modifier = Modifier.size(118.dp, 63.dp))
        Text(
            "puf",
            modifier = Modifier.fillMaxWidth().offset(y = 22.dp),
            textAlign = TextAlign.Center,
            style = TextStyle(
                fontFamily = Bagel, fontSize = 28.sp, color = C.Yellow,
                shadow = TextShadow(Color.White, Offset(0f, 4f), 0f)
            )
        )
    }
}

/** Inflatable rail: dashed seam, the active segment is a yellow balloon with a knot and string. */
@Composable
fun BalloonRail(options: List<String>, selected: Int, modifier: Modifier = Modifier, enabled: (Int) -> Boolean = { true }, onPick: (Int) -> Unit) {
    Column(modifier) {
        Box(
            Modifier.fillMaxWidth()
                .balloon(WhiteStops, RoundedCornerShape(30.dp), 10.dp, gloss = false)
                .drawBehind {
                    drawRoundRect(
                        Color(0x2216483A), topLeft = Offset(3.dp.toPx(), 3.dp.toPx()),
                        size = androidx.compose.ui.geometry.Size(size.width - 6.dp.toPx(), size.height - 6.dp.toPx()),
                        cornerRadius = CornerRadius(27.dp.toPx()),
                        style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 5.dp.toPx())))
                    )
                }
                .padding(4.dp)
        ) {
            Row(Modifier.fillMaxWidth()) {
                options.forEachIndexed { i, label ->
                    val on = i == selected
                    val en = enabled(i)
                    Box(
                        Modifier.weight(1f).height(44.dp)
                            .clickable(remember { MutableInteractionSource() }, null, enabled = en) { onPick(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (on) {
                            Box(Modifier.matchParentSize().padding(horizontal = 1.dp).balloon(YellowStops, RoundedCornerShape(22.dp), 4.dp))
                            Canvas(Modifier.align(Alignment.BottomCenter).offset(y = 22.dp).size(14.dp, 24.dp)) {
                                val w = size.width
                                val knot = Path().apply {
                                    moveTo(w / 2, 0f); lineTo(w / 2 + 4.dp.toPx(), 5.dp.toPx()); lineTo(w / 2 - 4.dp.toPx(), 5.dp.toPx()); close()
                                }
                                drawPath(knot, Color(0xFFD69A00))
                                val s = Path().apply {
                                    moveTo(w / 2, 5.dp.toPx())
                                    cubicTo(w / 2 - 6.dp.toPx(), 9.dp.toPx(), w / 2 + 6.dp.toPx(), 13.dp.toPx(), w / 2, 17.dp.toPx())
                                    cubicTo(w / 2 - 4.dp.toPx(), 20.dp.toPx(), w / 2 + 3.dp.toPx(), 22.dp.toPx(), w / 2, 24.dp.toPx())
                                }
                                drawPath(s, C.Mu, style = Stroke(1.4.dp.toPx(), cap = StrokeCap.Round))
                            }
                        }
                        Text(
                            label, maxLines = 1,
                            style = TextStyle(fontFamily = Manrope, fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold,
                                color = if (on) C.Ink else if (en) C.Mu else C.Mu.copy(alpha = 0.4f))
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

data class NavItem(val label: String, val icon: Int)

/** Floating white bar with a notch; the yellow balloon in the notch is the centre action. */
@Composable
fun NotchNavBar(
    left: List<NavItem>, right: List<NavItem>, selected: Int, centerIcon: Int, centerLabel: String,
    centerSelected: Boolean, onPick: (Int) -> Unit, onCenter: () -> Unit
) {
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 14.dp, end = 14.dp, top = 30.dp, bottom = 10.dp).height(72.dp)) {
        Canvas(Modifier.fillMaxWidth().height(72.dp)) {
            val w = size.width
            val h = size.height
            val r = h / 2
            val cx = w / 2
            val d = 1.dp.toPx()
            val p = Path().apply {
                moveTo(r, 0f)
                lineTo(cx - 53 * d, 0f)
                cubicTo(cx - 38 * d, 0f, cx - 34 * d, 7 * d, cx - 30 * d, 16 * d)
                cubicTo(cx - 22 * d, 44 * d, cx + 22 * d, 44 * d, cx + 30 * d, 16 * d)
                cubicTo(cx + 34 * d, 7 * d, cx + 38 * d, 0f, cx + 53 * d, 0f)
                lineTo(w - r, 0f)
                arcTo(Rect(w - 2 * r, 0f, w, h), -90f, 180f, false)
                lineTo(r, h)
                arcTo(Rect(0f, 0f, 2 * r, h), 90f, 180f, false)
                close()
            }
            drawIntoCanvas { c ->
                val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.White.toArgb()
                    setShadowLayer(18 * d, 0f, 8 * d, Color(0x38102820).toArgb())
                }
                c.nativeCanvas.drawPath(p.asAndroidPath(), paint)
            }
        }
        Row(Modifier.fillMaxWidth().height(72.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            left.forEachIndexed { i, it -> NavCell(it, i == selected, Modifier.weight(1f)) { onPick(i) } }
            Spacer(Modifier.width(76.dp))
            right.forEachIndexed { j, it ->
                val i = left.size + j
                NavCell(it, i == selected, Modifier.weight(1f)) { onPick(i) }
            }
        }
        Box(
            Modifier.align(Alignment.TopCenter).offset(y = (-30).dp).size(62.dp, 70.dp)
                .clickable(remember { MutableInteractionSource() }, null) { onCenter() }
        ) {
            Box(
                Modifier.size(62.dp).balloon(YellowStops, CircleShape, 12.dp)
                    .then(if (centerSelected) Modifier.drawBehind {
                        drawCircle(C.Green, radius = size.minDimension / 2 + 3.dp.toPx(), style = Stroke(3.dp.toPx()))
                    } else Modifier),
                contentAlignment = Alignment.Center
            ) {
                Image(painterResource(centerIcon), centerLabel, Modifier.size(34.dp).rotate(-8f))
            }
            Canvas(Modifier.align(Alignment.BottomCenter).size(10.dp, 8.dp)) {
                val p = Path().apply { moveTo(size.width / 2, 0f); lineTo(size.width, size.height); lineTo(0f, size.height); close() }
                drawPath(p, Color(0xFFD99E00))
            }
        }
    }
}

@Composable
private fun NavCell(item: NavItem, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(60.dp).clickable(remember { MutableInteractionSource() }, null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
    ) {
        Image(painterResource(item.icon), null, Modifier.size(if (on) 28.dp else 24.dp))
        Text(item.label, style = TextStyle(fontFamily = Manrope, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = if (on) C.Ink else C.Mu))
        Box(Modifier.padding(top = 2.dp).size(5.dp).background(if (on) C.Yellow else Color.Transparent, CircleShape))
    }
}
