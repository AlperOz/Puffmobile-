package com.alper.puf

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer

class NotSupportedLink(msg: String) : Exception(msg)

private val PAGE_HOSTS = listOf(
    "youtube.com", "youtu.be", "instagram.com", "tiktok.com", "facebook.com", "fb.watch",
    "twitter.com", "x.com", "vimeo.com", "dailymotion.com", "spotify.com", "soundcloud.com", "twitch.tv"
)

object Converter {
    fun checkLink(url: String) {
        val u = try { Uri.parse(url) } catch (e: Exception) { null }
        val host = u?.host?.lowercase() ?: throw NotSupportedLink("Geçerli bir link değil")
        if (u!!.scheme != "http" && u.scheme != "https") throw NotSupportedLink("Geçerli bir link değil")
        if (PAGE_HOSTS.any { host == it || host.endsWith(".$it") }) {
            throw NotSupportedLink("Bu bir platform sayfası linki. Puf yalnızca doğrudan dosya linklerini (.mp4, .mov, .webm…) dönüştürür.")
        }
    }

    suspend fun download(url: String, dest: File, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = true
        c.connectTimeout = 15000
        c.readTimeout = 30000
        try {
            c.connect()
            if (c.responseCode !in 200..299) throw Exception("Sunucu ${c.responseCode} döndürdü")
            val ct = c.contentType?.lowercase() ?: ""
            if (ct.startsWith("text/") || ct.contains("html")) {
                throw NotSupportedLink("Bu link bir dosya değil, bir web sayfası. Doğrudan video dosyası linki gerekiyor.")
            }
            val total = c.contentLengthLong
            var done = 0L
            c.inputStream.use { input ->
                dest.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress(done.toFloat() / total)
                    }
                }
            }
        } finally {
            c.disconnect()
        }
    }

    /** Copies the audio track into a new file without re-encoding (original quality). */
    fun extractAudio(ctx: Context, source: Uri, outDir: File, baseName: String): File {
        val ex = MediaExtractor()
        try {
            if (source.scheme == "file") ex.setDataSource(source.path!!) else ex.setDataSource(ctx, source, null)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    track = i; format = f; break
                }
            }
            if (track < 0 || format == null) throw Exception("Bu dosyada ses bulunamadı")
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            val (container, ext) = when {
                mime == MediaFormat.MIMETYPE_AUDIO_AAC -> MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4 to "m4a"
                mime == MediaFormat.MIMETYPE_AUDIO_OPUS || mime == MediaFormat.MIMETYPE_AUDIO_VORBIS ->
                    MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM to "webm"
                else -> throw Exception("Bu ses biçimi ($mime) henüz desteklenmiyor")
            }
            val out = File(outDir, "donustur_${baseName}.$ext").let { f ->
                var file = f
                var n = 2
                while (file.exists()) {
                    file = File(outDir, "donustur_${baseName}_$n.$ext"); n++
                }
                file
            }
            val muxer = MediaMuxer(out.absolutePath, container)
            try {
                val dst = muxer.addTrack(format)
                muxer.start()
                ex.selectTrack(track)
                val size = if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE) else 1 shl 20
                val buf = ByteBuffer.allocate(maxOf(size, 256 * 1024))
                val info = MediaCodec.BufferInfo()
                while (true) {
                    buf.clear()
                    val n = ex.readSampleData(buf, 0)
                    if (n < 0) break
                    info.offset = 0
                    info.size = n
                    info.presentationTimeUs = ex.sampleTime
                    info.flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    muxer.writeSampleData(dst, buf, info)
                    ex.advance()
                }
                muxer.stop()
            } finally {
                muxer.release()
            }
            return out
        } finally {
            ex.release()
        }
    }

    fun safeName(raw: String): String =
        raw.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9ÇĞİÖŞÜçğıöşü _-]"), "").trim().take(40).ifBlank { "ses" }
}

@Composable
fun DonusturScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<Float?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    fun finish(out: File) {
        status = "Hazır: ${out.name.removePrefix("donustur_")} · Kütüphane'ye eklendi"
        isError = false
        Toast.makeText(ctx, "Ses Kütüphane'ye eklendi", Toast.LENGTH_SHORT).show()
        onDone()
    }

    fun fail(e: Exception) {
        status = e.message ?: "Bir hata oldu"
        isError = true
    }

    fun convertLink() {
        val link = url.trim()
        try {
            Converter.checkLink(link)
        } catch (e: NotSupportedLink) {
            fail(e); return
        }
        busy = true; isError = false; progress = 0f; status = "İndiriliyor…"
        scope.launch {
            val tmp = File(ctx.cacheDir, "dl_tmp")
            try {
                Converter.download(link, tmp) { p -> progress = p }
                progress = null; status = "Ses ayrılıyor…"
                val name = Converter.safeName(Uri.parse(link).lastPathSegment ?: "ses")
                val out = withContext(Dispatchers.IO) { Converter.extractAudio(ctx, Uri.fromFile(tmp), recordingsDir(ctx), name) }
                url = ""
                finish(out)
            } catch (e: Exception) {
                fail(e)
            } finally {
                tmp.delete(); busy = false; progress = null
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true; isError = false; status = "Ses ayrılıyor…"
        scope.launch {
            try {
                var display = "video"
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) display = it.getString(0) ?: display
                }
                val out = withContext(Dispatchers.IO) {
                    Converter.extractAudio(ctx, uri, recordingsDir(ctx), Converter.safeName(display))
                }
                finish(out)
            } catch (e: Exception) {
                fail(e)
            } finally {
                busy = false
            }
        }
    }

    Column(
        Modifier.fillMaxSize().pufBackground().statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        PufLogo()
        Text("Dönüştür", style = H1)
        Text("Videonun sesini ayır, orijinal kalitede kaydet.", style = Body)

        Text("Doğrudan dosya linki", style = Strong.copy(fontSize = 13.sp), modifier = Modifier.padding(top = 18.dp))
        Row(
            Modifier.padding(top = 8.dp).fillMaxWidth().height(54.dp)
                .background(Color.White, RoundedCornerShape(27.dp)).padding(start = 18.dp, end = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.weight(1f)) {
                if (url.isEmpty()) Text("https://…/video.mp4", style = Body.copy(fontSize = 14.sp))
                BasicTextField(url, { url = it }, singleLine = true, enabled = !busy,
                    textStyle = TextStyle(fontFamily = Manrope, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = C.Ink),
                    modifier = Modifier.fillMaxWidth())
            }
            BalloonButton("Dönüştür", stops = GreenStops, textColor = Color.White, height = 40.dp,
                onClick = { if (!busy && url.isNotBlank()) convertLink() })
        }

        Text("ya da", style = Body, modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 14.dp))

        Row(
            Modifier.fillMaxWidth().height(110.dp).grooveTray(RoundedCornerShape(26.dp)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PopIcon(R.drawable.ic_bolt, 90.dp, 80.dp, 92.dp, corner = 20.dp, modifier = Modifier.padding(start = 12.dp))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text("Telefondaki video", style = Strong)
                Text("Galeriden ya da dosyalardan seç", style = Body.copy(fontSize = 12.sp))
            }
            BalloonButton("Seç", Modifier.padding(end = 12.dp), height = 44.dp,
                onClick = { if (!busy) picker.launch(arrayOf("video/*", "audio/*")) })
        }

        status?.let { s ->
            Column(
                Modifier.padding(top = 18.dp).fillMaxWidth()
                    .background(if (isError) Color(0xFFFFE3D6) else Color.White, RoundedCornerShape(20.dp)).padding(16.dp)
            ) {
                Text(s, style = Strong.copy(fontSize = 13.sp, color = if (isError) C.Coral else C.Ink))
                val p = progress
                if (busy) {
                    Box(Modifier.padding(top = 10.dp).fillMaxWidth().height(8.dp).background(C.Field, RoundedCornerShape(4.dp))) {
                        Box(
                            Modifier.fillMaxWidth(p ?: 0.5f).height(8.dp)
                                .background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(C.YellowLight, C.Yellow)), RoundedCornerShape(4.dp))
                        )
                    }
                }
            }
        }

        Text(
            "Yalnızca indirme izni olan doğrudan dosya linkleri desteklenir. YouTube, Instagram, TikTok gibi platform sayfaları dönüştürülmez. Ses yeniden kodlanmadan ayrılır (genelde M4A); MP3 bu sürümde yok.",
            style = Body.copy(fontSize = 12.sp),
            modifier = Modifier.padding(top = 18.dp).fillMaxWidth()
                .background(Color(0xB3FFFFFF), RoundedCornerShape(18.dp)).padding(14.dp)
        )
        Spacer(Modifier.height(30.dp))
    }
}
