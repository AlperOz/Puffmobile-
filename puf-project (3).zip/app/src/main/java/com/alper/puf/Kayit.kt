package com.alper.puf

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

@Composable
fun KayitScreen(onRecorded: () -> Unit) {
    val ctx = LocalContext.current
    val rec by RecordService.state.collectAsState()
    val captureSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
    var mode by remember { mutableStateOf(lastRecMode(ctx)) }
    val bubbleOn by BubbleService.running.collectAsState()
    var elapsed by remember { mutableLongStateOf(0L) }
    var sawRecording by remember { mutableStateOf(false) }

    LaunchedEffect(rec.recording) {
        if (rec.recording) sawRecording = true
        while (rec.recording) {
            elapsed = (System.currentTimeMillis() - rec.startedAt) / 1000
            delay(500)
        }
        if (!rec.recording && sawRecording && rec.lastFile != null) {
            sawRecording = false
            Toast.makeText(ctx, "Kayıt kütüphaneye eklendi", Toast.LENGTH_SHORT).show()
            onRecorded()
        }
    }
    LaunchedEffect(rec.error) { rec.error?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() } }

    fun startService(extra: Intent.() -> Unit) {
        val i = Intent(ctx, RecordService::class.java).apply(extra)
        ContextCompat.startForegroundService(ctx, i)
    }

    val projectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK && res.data != null) {
            startService {
                putExtra(RecordService.EXTRA_MODE, MODE_CAPTURE)
                putExtra(RecordService.EXTRA_CODE, res.resultCode)
                putExtra(RecordService.EXTRA_DATA, res.data)
            }
        } else {
            Toast.makeText(ctx, "Telefon sesi için izin verilmedi", Toast.LENGTH_SHORT).show()
        }
    }

    fun begin() {
        if (mode == MODE_CAPTURE && captureSupported) {
            val mpm = ctx.getSystemService(MediaProjectionManager::class.java)
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        } else {
            startService { putExtra(RecordService.EXTRA_MODE, MODE_MIC) }
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        if (granted[Manifest.permission.RECORD_AUDIO] == true) begin()
        else Toast.makeText(ctx, "Kayıt için mikrofon izni gerekli", Toast.LENGTH_SHORT).show()
    }

    fun onRecordTap() {
        if (rec.recording) {
            RecordService.stop(ctx); return
        }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        val missing = need.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) begin() else permLauncher.launch(missing.toTypedArray())
    }

    val spin by rememberInfiniteTransition(label = "tape").animateFloat(
        -6f, 6f, infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse), label = "tilt"
    )
    val bob by rememberInfiniteTransition(label = "bob").animateFloat(
        0f, -10f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "bob"
    )

    Column(
        Modifier.fillMaxSize().pufBackground().statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(Modifier.fillMaxWidth()) {
            PufLogo()
            Text("Kayıt", style = H1)
            Text("Mikrofonu ya da telefonda çalan sesi kaydet.", style = Body)
        }
        BalloonRail(
            listOf("Mikrofon", "Telefonun sesi"), if (mode == MODE_MIC) 0 else 1,
            Modifier.padding(top = 16.dp),
            enabled = { (it == 0 || captureSupported) && !rec.recording }
        ) { mode = if (it == 0) MODE_MIC else MODE_CAPTURE; saveRecMode(ctx, mode) }

        Box(Modifier.padding(top = 6.dp).size(260.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(240.dp).grooveTray(CircleShape))
            Image(
                painterResource(R.drawable.ic_tape), null,
                Modifier.width(230.dp)
                    .offset(y = if (rec.recording) bob.dp else 0.dp)
                    .rotate(if (rec.recording) spin else -6f)
            )
        }

        Text(
            if (rec.recording) String.format("%02d:%02d", elapsed / 60, elapsed % 60) else "00:00",
            style = TextStyle(fontFamily = Manrope, fontSize = 44.sp, fontWeight = FontWeight.ExtraBold, color = C.Ink),
            modifier = Modifier.padding(top = 8.dp)
        )
        Text(
            when {
                rec.recording && rec.mode == MODE_CAPTURE -> "Telefonun sesi kaydediliyor"
                rec.recording -> "Mikrofon kaydediliyor"
                else -> "Hazır"
            },
            style = Body
        )

        Box(
            Modifier.padding(top = 20.dp).size(96.dp)
                .balloon(if (rec.recording) GreenStops else YellowStops, CircleShape, 12.dp)
                .clickable { onRecordTap() },
            contentAlignment = Alignment.Center
        ) {
            if (rec.recording) Box(Modifier.size(30.dp).background(Color.White, RoundedCornerShape(8.dp)))
            else Box(Modifier.size(34.dp).background(C.Coral, CircleShape))
        }
        Text(if (rec.recording) "Durdur" else "Kaydet", style = Strong, modifier = Modifier.padding(top = 8.dp))

        Row(
            Modifier.padding(top = 18.dp).fillMaxWidth().height(86.dp).grooveTray(RoundedCornerShape(24.dp)).padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(50.dp).balloon(YellowStops, CircleShape, 6.dp), contentAlignment = Alignment.Center) {
                Image(painterResource(R.drawable.ic_tape), null, Modifier.size(34.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text("Yüzen kayıt butonu", style = Strong)
                Text("Her uygulamanın üstünde durur; dokun, kaydet.", style = Body.copy(fontSize = 12.sp))
            }
            BalloonButton(if (bubbleOn) "Kapat" else "Aç", height = 40.dp,
                stops = if (bubbleOn) WhiteStops else GreenStops, textColor = if (bubbleOn) C.Ink else Color.White,
                onClick = {
                    if (bubbleOn) BubbleService.stop(ctx)
                    else if (!canDrawOverlay(ctx)) {
                        Toast.makeText(ctx, "puf için \"Diğer uygulamaların üzerinde göster\" iznini aç, sonra geri dön", Toast.LENGTH_LONG).show()
                        ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            android.net.Uri.parse("package:" + ctx.packageName)))
                    } else BubbleService.start(ctx)
                })
        }

        if (mode == MODE_CAPTURE) {
            Text(
                "Android her uygulamaya kendi sesinin kaydedilip kaydedilmeyeceğini seçtirir. Kayda izin vermeyen uygulamalar (örneğin YouTube) ve puf'un kendi oynatıcısı sessiz kaydedilir. Telefon ekran paylaşımı izni isteyecek; görüntü kaydedilmez, sadece ses.",
                style = Body.copy(fontSize = 12.sp), textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 16.dp).fillMaxWidth()
                    .background(Color(0xB3FFFFFF), RoundedCornerShape(18.dp)).padding(14.dp)
            )
        } else if (!captureSupported) {
            Text("Telefonun sesini kaydetmek Android 10 ve üstünde çalışır.", style = Body.copy(fontSize = 12.sp),
                modifier = Modifier.padding(top = 16.dp))
        }
        Spacer(Modifier.height(30.dp))
    }
}
