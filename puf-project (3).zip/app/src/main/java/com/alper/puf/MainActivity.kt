package com.alper.puf

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private lateinit var store: Store
    private lateinit var hub: PlayerHub
    private var sharedText by mutableStateOf<String?>(null)
    private var tab by mutableIntStateOf(TAB_LIB)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(applicationContext)
        hub = PlayerHub(applicationContext)
        handleShare(intent)
        setContent {
            PufTheme {
                var watching by remember { mutableStateOf<LinkItem?>(null) }
                var libRefresh by remember { mutableIntStateOf(0) }
                val w = watching
                if (w != null) {
                    IzleScreen(store, w, onBack = { watching = null })
                } else {
                    Column(Modifier.fillMaxSize().pufBackground()) {
                        Box(Modifier.weight(1f)) {
                            when (tab) {
                                TAB_LIB -> KutuphaneScreen(hub, libRefresh)
                                TAB_REC -> KayitScreen(onRecorded = { libRefresh++ })
                                TAB_COL -> KoleksiyonScreen(
                                    store = store,
                                    shared = sharedText,
                                    onSharedUsed = { sharedText = null },
                                    onWatch = {
                                        hub.controller?.pause()
                                        watching = it
                                    }
                                )
                                TAB_NOW -> CalanScreen(hub, onEmptyAction = { tab = TAB_LIB })
                                else -> DonusturScreen(onDone = { libRefresh++ })
                            }
                        }
                        if (tab != TAB_NOW) {
                            Box(Modifier.clickable { tab = TAB_NOW }) { MiniPlayer(hub, Modifier.padding(top = 6.dp)) }
                        }
                        NotchNavBar(
                            left = listOf(NavItem("Kütüphane", R.drawable.ic_head), NavItem("Kayıt", R.drawable.ic_tape)),
                            right = listOf(NavItem("Linkler", R.drawable.ic_moon), NavItem("Çalıyor", R.drawable.ic_wave)),
                            selected = tab,
                            centerIcon = R.drawable.ic_bolt, centerLabel = "Dönüştür",
                            centerSelected = tab == TAB_CONV,
                            onPick = { tab = it },
                            onCenter = { tab = TAB_CONV }
                        )
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        hub.connect()
    }

    override fun onStop() {
        hub.release()
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let {
                sharedText = it
                tab = TAB_COL
            }
        }
    }
}

const val TAB_LIB = 0
const val TAB_REC = 1
const val TAB_COL = 2
const val TAB_NOW = 3
const val TAB_CONV = 4
