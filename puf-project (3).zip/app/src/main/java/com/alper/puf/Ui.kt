package com.alper.puf

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Manrope = androidx.compose.ui.text.font.FontFamily(
    androidx.compose.ui.text.font.Font(R.font.manrope_500, FontWeight.Medium),
    androidx.compose.ui.text.font.Font(R.font.manrope_600, FontWeight.SemiBold),
    androidx.compose.ui.text.font.Font(R.font.manrope_700, FontWeight.Bold),
    androidx.compose.ui.text.font.Font(R.font.manrope_800, FontWeight.ExtraBold),
    androidx.compose.ui.text.font.Font(R.font.manrope_800, FontWeight.Black),
    androidx.compose.ui.text.font.Font(R.font.manrope_500, FontWeight.Normal)
)
val Bagel = androidx.compose.ui.text.font.FontFamily(androidx.compose.ui.text.font.Font(R.font.bagel))

object C {
    val Mint = Color(0xFFDDF0E8)
    val Ink = Color(0xFF12261F)
    val Mu = Color(0xFF5A6D65)
    val Green = Color(0xFF16483A)
    val Dark = Color(0xFF0A2C23)
    val Yellow = Color(0xFFF2B705)
    val YellowLight = Color(0xFFFFE173)
    val Field = Color(0xFFF1F7F4)
    val Chip = Color(0xFFE4F2EB)
    val Coral = Color(0xFFC04A26)
}

val YellowStops = listOf(Color(0xFFFFF8D6), Color(0xFFFFDE5C), Color(0xFFF2B705), Color(0xFFCF9300))
val GreenStops = listOf(Color(0xFF2F6E57), Color(0xFF16483A), Color(0xFF0A2C23))
val WhiteStops = listOf(Color(0xFFFFFFFF), Color(0xFFF5F9F7), Color(0xFFDCE9E3))

@Composable
fun PufTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = C.Green, onPrimary = Color.White,
            background = C.Mint, surface = Color.White, onSurface = C.Ink
        ),
        content = content
    )
}

/** Inflated "balloon" fill: radial gradient lit from the top-left plus a small glossy highlight. */
fun Modifier.balloon(stops: List<Color>, shape: Shape, elevation: Dp = 8.dp, gloss: Boolean = true): Modifier =
    this
        .shadow(elevation, shape, ambientColor = Color(0x5510281F), spotColor = Color(0x6610281F))
        .drawWithCache {
            val outline = shape.createOutline(size, layoutDirection, this)
            val brush = Brush.radialGradient(
                colors = stops,
                center = Offset(size.width * 0.3f, size.height * 0.18f),
                radius = size.maxDimension * 0.95f
            )
            onDrawBehind {
                drawOutline(outline, brush)
                if (gloss) {
                    val w = (size.minDimension * 0.32f).coerceAtMost(28.dp.toPx())
                    drawOval(
                        Color.White.copy(alpha = 0.75f),
                        topLeft = Offset(size.minDimension * 0.22f, size.height * 0.1f),
                        size = Size(w, w * 0.42f)
                    )
                }
            }
        }

/** Mint→butter tray with faint record grooves, used behind pop-out icons. */
fun Modifier.grooveTray(shape: Shape): Modifier =
    this
        .background(Brush.linearGradient(listOf(Color(0xFFE4F5EC), Color(0xFFFFF3C4))), shape)
        .drawBehind {
            val c = Offset(size.width / 2, size.height * 1.15f)
            var r = 6.dp.toPx()
            while (r < size.maxDimension * 1.3f) {
                drawCircle(Color(0x1416483A), r, c, style = Stroke(1.dp.toPx()))
                r += 6.dp.toPx()
            }
        }

/** Icon that pops out above its tray (the "taşma" effect). */
@Composable
fun PopIcon(icon: Int, w: Dp, h: Dp, iconH: Dp, corner: Dp = 16.dp, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(corner)
    Box(modifier.size(w, h).grooveTray(shape)) {
        Image(
            painterResource(icon), contentDescription = null,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 4.dp)
                .size(iconH)
                .rotate(-6f)
        )
    }
}

@Composable
fun BalloonButton(
    text: String,
    modifier: Modifier = Modifier,
    stops: List<Color> = YellowStops,
    textColor: Color = C.Ink,
    height: Dp = 52.dp,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(height / 2)
    Box(
        modifier
            .height(height)
            .balloon(stops, shape, gloss = stops === YellowStops)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = TextStyle(fontFamily = Manrope, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = textColor))
    }
}

val H1 = TextStyle(fontFamily = Manrope, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = C.Ink, letterSpacing = (-0.5).sp)
val H2 = TextStyle(fontFamily = Manrope, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = C.Ink)
val Body = TextStyle(fontFamily = Manrope, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = C.Mu, lineHeight = 19.sp)
val Strong = TextStyle(fontFamily = Manrope, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = C.Ink)
