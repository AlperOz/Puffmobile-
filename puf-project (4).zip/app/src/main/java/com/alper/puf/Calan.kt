package com.alper.puf

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private fun mmss(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

/** Full "now playing" screen: grooved plate + floating cassette whose reels spin while playing. */
@Composable
fun CalanScreen(hub: PlayerHub, onEmptyAction: () -> Unit) {
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    LaunchedEffect(hub.title, hub.isPlaying) {
        while (true) {
            pos = hub.position(); dur = hub.duration()
            delay(500)
        }
    }
    val tr = rememberInfiniteTransition(label = "calan")
    val spin by tr.animateFloat(0f, 360f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "spin")
    val bob by tr.animateFloat(0f, -8f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "bob")
    val playing = hub.isPlaying

    Column(
        Modifier.fillMaxSize().pufBackground().statusBarsPadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            PufLogo()
            Spacer(Modifier.weight(1f))
            Text("Şimdi çalıyor", style = Strong.copy(fontSize = 13.sp, color = C.Mu))
        }

        BoxWithConstraints(Modifier.padding(top = 12.dp).fillMaxWidth().aspectRatio(1f), contentAlignment = Alignment.Center) {
            val plate = maxWidth * 0.86f
            Box(
                Modifier.size(plate).background(Color.White, CircleShape).padding(10.dp)
                    .drawBehind {
                        val c = Offset(size.width / 2, size.height / 2)
                        drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF6CF), Color(0xFFE4F5EC)), c, size.minDimension / 2), size.minDimension / 2, c)
                        var r = size.minDimension * 0.18f
                        while (r < size.minDimension / 2) {
                            drawCircle(Color(0x1A16483A), r, c, style = Stroke(1.dp.toPx())); r += 5.dp.toPx()
                        }
                    }
            )
            val tapeW = maxWidth * 0.92f
            val tapeH = tapeW * (463f / 640f)
            Box(
                Modifier.offset(y = if (playing) bob.dp + 30.dp else 30.dp).size(tapeW, tapeH)
                    .rotate(if (playing) 0f else -4f)
            ) {
                Image(painterResource(R.drawable.tape_full), null, Modifier.fillMaxSize())
                Image(
                    painterResource(R.drawable.reel_l), null,
                    Modifier.offset(x = tapeW * 0.1779f, y = tapeH * 0.2688f).size(tapeW * 0.2327f).rotate(if (playing) spin else 0f)
                )
                Image(
                    painterResource(R.drawable.reel_r), null,
                    Modifier.offset(x = tapeW * 0.5787f, y = tapeH * 0.3423f).size(tapeW * 0.2327f).rotate(if (playing) spin else 0f)
                )
            }
        }

        val title = hub.title
        if (title == null) {
            Text("Şu an bir şey çalmıyor", style = H2, modifier = Modifier.padding(top = 8.dp))
            Text("Kütüphane'den bir kayıt ya da şarkı seç.", style = Body)
            BalloonButton("Kütüphane'ye git", Modifier.padding(top = 14.dp), onClick = onEmptyAction)
            return@Column
        }
        Text(title, style = H2.copy(fontSize = 24.sp), maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp).fillMaxWidth())
        Text(hub.subtitle, style = Body, maxLines = 1, overflow = TextOverflow.Ellipsis)

        // progress: tap or drag to seek
        var dragFrac by remember { mutableStateOf<Float?>(null) }
        val live = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
        val frac = dragFrac ?: live
        BoxWithConstraints(
            Modifier.padding(top = 18.dp).fillMaxWidth().height(32.dp)
                .pointerInput(dur) {
                    detectTapGestures { o -> if (dur > 0) hub.seekTo((o.x / size.width * dur).toLong()) }
                }
                .pointerInput(dur) {
                    detectHorizontalDragGestures(
                        onDragStart = { o -> dragFrac = (o.x / size.width).coerceIn(0f, 1f) },
                        onDragEnd = { dragFrac?.let { if (dur > 0) hub.seekTo((it * dur).toLong()) }; dragFrac = null },
                        onDragCancel = { dragFrac = null }
                    ) { change, _ ->
                        dragFrac = (change.position.x / size.width).coerceIn(0f, 1f)
                    }
                },
            contentAlignment = Alignment.CenterStart
        ) {
            val trackW = maxWidth
            Box(Modifier.fillMaxWidth().height(8.dp).background(Color.White, RoundedCornerShape(4.dp)))
            Box(Modifier.fillMaxWidth(frac).height(8.dp).background(Brush.horizontalGradient(listOf(C.YellowLight, C.Yellow)), RoundedCornerShape(4.dp)))
            Box(
                Modifier.offset(x = (trackW - 24.dp) * frac).size(24.dp)
                    .balloon(YellowStops, CircleShape, 6.dp, gloss = false)
            )
        }
        Row(Modifier.fillMaxWidth()) {
            Text(mmss(dragFrac?.let { (it * dur).toLong() } ?: pos), style = Body.copy(fontSize = 12.sp))
            Spacer(Modifier.weight(1f))
            Text(mmss(dur), style = Body.copy(fontSize = 12.sp))
        }

        Row(
            Modifier.padding(top = 10.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
        ) {
            CtlBall("⏮") { hub.previous() }
            Box(
                Modifier.size(84.dp).balloon(YellowStops, CircleShape, 14.dp).clickable { hub.toggle() },
                contentAlignment = Alignment.Center
            ) {
                Text(if (playing) "❚❚" else "▶", style = TextStyle(fontFamily = Manrope, fontSize = 26.sp, fontWeight = FontWeight.Black, color = C.Ink))
            }
            CtlBall("⏭") { hub.next() }
        }

        BalloonRail(
            listOf("Sıralı çal", "Tekli çal"), if (hub.sequential) 0 else 1,
            Modifier.padding(top = 18.dp)
        ) { hub.changeSequential(it == 0) }
        Text(
            if (hub.sequential) "Liste bitene kadar sırayla çalar." else "Seçtiğin şarkı biter ve durur.",
            style = Body.copy(fontSize = 12.sp)
        )
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun CtlBall(sym: String, onClick: () -> Unit) {
    Box(Modifier.size(58.dp).balloon(WhiteStops, CircleShape, 8.dp, gloss = false).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(sym, style = TextStyle(fontFamily = Manrope, fontSize = 20.sp, color = C.Green))
    }
}
