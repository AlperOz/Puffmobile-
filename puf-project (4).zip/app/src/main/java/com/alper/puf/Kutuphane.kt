package com.alper.puf

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun loadRecordings(ctx: Context): List<Track> =
    (recordingsDir(ctx).listFiles() ?: emptyArray())
        .filter { it.isFile && it.length() > 44 && (it.extension in setOf("m4a", "wav", "webm")) }
        .sortedByDescending { it.lastModified() }
        .map { f ->
            val date = SimpleDateFormat("d MMM HH:mm", Locale("tr")).format(Date(f.lastModified()))
            if (f.name.startsWith("donustur_")) {
                Track("rec:" + f.name, Uri.fromFile(f), f.nameWithoutExtension.removePrefix("donustur_"),
                    "Dönüştürülen · $date · ${formatMb(f.length())}", true)
            } else {
                val kind = if (f.extension == "wav") "Telefon sesi" else "Mikrofon"
                Track("rec:" + f.name, Uri.fromFile(f), "Kayıt · $date", "$kind · ${formatMb(f.length())}", true)
            }
        }

suspend fun loadDeviceMusic(ctx: Context): List<Track> = withContext(Dispatchers.IO) {
    val out = mutableListOf<Track>()
    val col = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
    try {
        ctx.contentResolver.query(col, proj, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iT = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iA = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val artist = c.getString(iA)?.takeIf { it != "<unknown>" } ?: "Bilinmeyen sanatçı"
                out += Track("ms:$id", ContentUris.withAppendedId(col, id), c.getString(iT) ?: "Şarkı", artist, false)
            }
        }
    } catch (_: Exception) {
    }
    out
}

private fun audioPermission() =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

@Composable
fun KutuphaneScreen(hub: PlayerHub, refreshKey: Int) {
    val ctx = LocalContext.current
    var recordings by remember { mutableStateOf(loadRecordings(ctx)) }
    var music by remember { mutableStateOf<List<Track>>(emptyList()) }
    var hasPerm by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, audioPermission()) == PackageManager.PERMISSION_GRANTED)
    }
    var tab by remember { mutableIntStateOf(0) }
    var confirmDelete by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(refreshKey) { recordings = loadRecordings(ctx) }
    LaunchedEffect(hasPerm) { if (hasPerm) music = loadDeviceMusic(ctx) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPerm = it }

    val list = if (tab == 0) recordings else music

    LazyColumn(
        Modifier.fillMaxSize().pufBackground().statusBarsPadding(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column {
                PufLogo()
                Text("Bugün ne\ndinliyoruz?", style = H1.copy(lineHeight = 34.sp), modifier = Modifier.padding(top = 4.dp))
                Text("Kayıtların ve telefondaki müzikler; arka planda ve kilit ekranında çalar.", style = Body)
            }
        }
        item {
            BalloonRail(listOf("Kayıtlarım (${recordings.size})", "Telefondaki"), tab) { tab = it }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Çalma:", style = Strong.copy(fontSize = 13.sp))
                Spacer(Modifier.width(8.dp))
                listOf(true to "Sıralı", false to "Tekli").forEach { (v, label) ->
                    val on = hub.sequential == v
                    Box(
                        Modifier.padding(end = 8.dp).height(34.dp)
                            .then(if (on) Modifier.balloon(YellowStops, RoundedCornerShape(17.dp), 3.dp, gloss = false)
                                  else Modifier.background(Color.White, RoundedCornerShape(17.dp)))
                            .clickable { hub.changeSequential(v) }.padding(horizontal = 14.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(label, style = Strong.copy(fontSize = 12.sp, color = if (on) C.Ink else C.Mu)) }
                }
                Text(if (hub.sequential) "listeyi sırayla çalar" else "tek şarkı çalar, durur", style = Body.copy(fontSize = 11.sp))
            }
        }
        if (tab == 1 && !hasPerm) {
            item {
                Column(Modifier.fillMaxWidth().padding(top = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    PopIcon(R.drawable.ic_head, 150.dp, 120.dp, 130.dp, corner = 60.dp)
                    Text("Müziklerini görmek için izin ver", style = Strong.copy(fontSize = 16.sp), modifier = Modifier.padding(top = 16.dp))
                    BalloonButton("İzin ver", Modifier.padding(top = 12.dp), onClick = { permLauncher.launch(audioPermission()) })
                }
            }
        } else if (list.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(top = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    PopIcon(R.drawable.ic_tape, 150.dp, 110.dp, 110.dp, corner = 30.dp)
                    Text(if (tab == 0) "Henüz kayıt yok" else "Telefonda müzik bulunamadı",
                        style = Strong.copy(fontSize = 16.sp), modifier = Modifier.padding(top = 16.dp))
                    if (tab == 0) Text("Kayıt sekmesinden ilk kaydını al.", style = Body)
                }
            }
        }
        if (!(tab == 1 && !hasPerm)) {
            itemsIndexed(list, key = { _, t -> t.id }) { i, t ->
                val playingThis = hub.title == t.title
                Row(
                    Modifier.fillMaxWidth().height(72.dp).shadow(5.dp, RoundedCornerShape(22.dp))
                        .background(Color.White, RoundedCornerShape(22.dp))
                        .clickable { hub.play(list, i) }.padding(start = 10.dp, end = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PopIcon(if (t.isRecording) R.drawable.ic_tape else R.drawable.ic_head, 54.dp, 50.dp, 54.dp, corner = 14.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.title, style = Strong.copy(color = if (playingThis) C.Green else C.Ink), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(t.subtitle, style = Body.copy(fontSize = 12.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (t.isRecording) {
                        val name = t.id.removePrefix("rec:")
                        Text(
                            if (confirmDelete == name) "Silinsin mi?" else "Sil",
                            style = TextStyle(fontFamily = Manrope, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = C.Coral),
                            modifier = Modifier.clickable {
                                if (confirmDelete == name) {
                                    File(recordingsDir(ctx), name).delete()
                                    confirmDelete = null
                                    recordings = loadRecordings(ctx)
                                } else confirmDelete = name
                            }.padding(8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(hub: PlayerHub, modifier: Modifier = Modifier) {
    val title = hub.title ?: return
    Row(
        modifier.fillMaxWidth().padding(horizontal = 14.dp).height(64.dp)
            .shadow(12.dp, RoundedCornerShape(32.dp))
            .background(C.Dark, RoundedCornerShape(32.dp)).padding(start = 8.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PopIcon(R.drawable.ic_tape, 52.dp, 48.dp, 46.dp, corner = 24.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = TextStyle(fontFamily = Manrope, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Color.White),
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(hub.subtitle, style = TextStyle(fontFamily = Manrope, fontSize = 12.sp, color = Color(0xCCFFFFFF)), maxLines = 1)
        }
        RoundCtl("⏮") { hub.previous() }
        Box(
            Modifier.padding(horizontal = 4.dp).height(46.dp).width(46.dp)
                .balloon(YellowStops, androidx.compose.foundation.shape.CircleShape, 4.dp)
                .clickable { hub.toggle() },
            contentAlignment = Alignment.Center
        ) { Text(if (hub.isPlaying) "❚❚" else "▶", style = TextStyle(fontFamily = Manrope, fontSize = 16.sp, fontWeight = FontWeight.Black, color = C.Ink)) }
        RoundCtl("⏭") { hub.next() }
    }
}

@Composable
private fun RoundCtl(sym: String, onClick: () -> Unit) {
    Box(Modifier.height(40.dp).width(36.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(sym, style = TextStyle(fontFamily = Manrope, fontSize = 16.sp, color = Color.White))
    }
}
