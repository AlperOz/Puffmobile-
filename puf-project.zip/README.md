# puf

Kişisel test için Android uygulaması: YouTube linklerini kaydet, kategorile, resmî oynatıcıyla izle ya da YouTube Music'te sadece ses olarak aç.

APK her push'ta GitHub Actions ile derlenir; **Releases** sayfasından indirilir.
