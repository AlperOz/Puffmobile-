package com.alper.puf

import android.content.Context
import android.net.TrafficStats
import android.os.Process
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class LinkItem(
    val id: Long,
    val url: String,
    val videoId: String,
    val title: String,
    val cat: String,
    val added: Long
)

data class Cat(val key: String, val label: String, val icon: Int)

val CATS = listOf(
    Cat("lofi", "Lo-fi", R.drawable.ic_moon),
    Cat("pod", "Podcast", R.drawable.ic_cloud),
    Cat("live", "Canlı", R.drawable.ic_flame),
    Cat("konser", "Konser", R.drawable.ic_bolt),
    Cat("diger", "Diğer", R.drawable.ic_star)
)

fun catOf(key: String): Cat = CATS.firstOrNull { it.key == key } ?: CATS.last()

object YouTubeIds {
    private val patterns = listOf(
        Regex("youtu\\.be/([A-Za-z0-9_-]{11})"),
        Regex("[?&]v=([A-Za-z0-9_-]{11})"),
        Regex("/(?:shorts|embed|live)/([A-Za-z0-9_-]{11})")
    )

    fun extract(url: String): String? =
        patterns.firstNotNullOfOrNull { it.find(url)?.groupValues?.get(1) }
}

fun firstUrl(text: String): String? = Regex("https?://\\S+").find(text)?.value

/** Public oEmbed endpoint: returns the video title, no API key needed. */
suspend fun fetchTitle(url: String): String? = withContext(Dispatchers.IO) {
    try {
        val u = URL("https://www.youtube.com/oembed?format=json&url=" + URLEncoder.encode(url, "UTF-8"))
        val c = u.openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 6000
        try {
            if (c.responseCode != 200) null
            else JSONObject(c.inputStream.bufferedReader().readText()).optString("title").ifBlank { null }
        } finally {
            c.disconnect()
        }
    } catch (e: Exception) {
        null
    }
}

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("puf", Context.MODE_PRIVATE)

    var items by mutableStateOf(loadItems())
        private set
    var totalBytes by mutableLongStateOf(p.getLong("bytes", 0L))
        private set
    var totalSec by mutableLongStateOf(p.getLong("sec", 0L))
        private set
    var handoffs by mutableIntStateOf(p.getInt("handoffs", 0))
        private set
    var since by mutableLongStateOf(p.getLong("since", System.currentTimeMillis()))
        private set
    var dontShowAudioTip by mutableStateOf(p.getBoolean("dontShow", false))
        private set

    init {
        if (!p.contains("since")) p.edit().putLong("since", since).apply()
    }

    private fun loadItems(): List<LinkItem> {
        val raw = p.getString("items", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                LinkItem(
                    o.getLong("id"), o.getString("url"), o.getString("vid"),
                    o.getString("title"), o.getString("cat"), o.optLong("added")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveItems() {
        val a = JSONArray()
        items.forEach {
            a.put(
                JSONObject().put("id", it.id).put("url", it.url).put("vid", it.videoId)
                    .put("title", it.title).put("cat", it.cat).put("added", it.added)
            )
        }
        p.edit().putString("items", a.toString()).apply()
    }

    fun add(item: LinkItem) {
        items = listOf(item) + items.filter { it.videoId != item.videoId }
        saveItems()
    }

    fun remove(id: Long) {
        items = items.filter { it.id != id }
        saveItems()
    }

    fun addUsage(bytes: Long, sec: Long) {
        totalBytes += bytes
        totalSec += sec
        p.edit().putLong("bytes", totalBytes).putLong("sec", totalSec).apply()
    }

    fun countHandoff() {
        handoffs += 1
        p.edit().putInt("handoffs", handoffs).apply()
    }

    fun setDontShow(v: Boolean) {
        dontShowAudioTip = v
        p.edit().putBoolean("dontShow", v).apply()
    }

    fun resetStats() {
        totalBytes = 0; totalSec = 0; handoffs = 0; since = System.currentTimeMillis()
        p.edit().putLong("bytes", 0).putLong("sec", 0).putInt("handoffs", 0).putLong("since", since).apply()
    }
}

/** Measures this app's own network traffic and watch time while the in-app player plays. */
class Meter(private val store: Store) {
    private var startBytes = -1L
    private var startTime = 0L

    val running get() = startBytes >= 0

    fun start() {
        if (running) return
        startBytes = bytes()
        startTime = SystemClock.elapsedRealtime()
    }

    fun stop() {
        if (!running) return
        val db = (bytes() - startBytes).coerceAtLeast(0)
        val dt = (SystemClock.elapsedRealtime() - startTime) / 1000
        startBytes = -1
        store.addUsage(db, dt)
    }

    fun sessionBytes(): Long = if (running) (bytes() - startBytes).coerceAtLeast(0) else 0

    private fun bytes(): Long {
        val uid = Process.myUid()
        val r = TrafficStats.getUidRxBytes(uid)
        val t = TrafficStats.getUidTxBytes(uid)
        return if (r < 0 || t < 0) 0 else r + t
    }
}

fun formatMb(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1000) String.format("%.2f GB", mb / 1024) else "${mb.toInt()} MB"
}

fun formatTime(sec: Long): String {
    val m = sec / 60
    return if (m >= 60) "${m / 60} sa ${m % 60} dk" else "$m dk"
}
