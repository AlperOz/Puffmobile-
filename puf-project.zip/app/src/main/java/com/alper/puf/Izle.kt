package com.alper.puf

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import kotlinx.coroutines.delay

@Composable
fun IzleScreen(store: Store, start: LinkItem, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var current by remember { mutableStateOf(start) }
    var player by remember { mutableStateOf<YouTubePlayer?>(null) }
    var playing by remember { mutableStateOf(false) }
    var sessionBytes by remember { mutableLongStateOf(0L) }
    val meter = remember { Meter(store) }
    val viewHolder = remember { arrayOfNulls<YouTubePlayerView>(1) }

    BackHandler { onBack() }

    DisposableEffect(Unit) {
        onDispose {
            meter.stop()
            viewHolder[0]?.let { lifecycleOwner.lifecycle.removeObserver(it); it.release() }
        }
    }

    LaunchedEffect(playing) {
        while (playing) {
            sessionBytes = meter.sessionBytes()
            delay(1000)
        }
    }

    val next = store.items.filter { it.cat == current.cat && it.id != current.id }.take(5)

    Column(
        Modifier.fillMaxSize().background(C.Mint).statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).balloon(WhiteStops, CircleShape, 6.dp, gloss = false).clickable { onBack() },
                contentAlignment = Alignment.Center
            ) { Text("‹", style = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold, color = C.Green)) }
            Text("Burada izle", style = Strong, modifier = Modifier.weight(1f).padding(end = 46.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
        Box(
            Modifier.padding(top = 16.dp).fillMaxWidth().shadow(10.dp, RoundedCornerShape(26.dp))
                .background(Color.White, RoundedCornerShape(26.dp)).padding(6.dp)
        ) {
            AndroidView(
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(20.dp)),
                factory = { c ->
                    YouTubePlayerView(c).also { v ->
                        viewHolder[0] = v
                        lifecycleOwner.lifecycle.addObserver(v)
                        v.addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
                            override fun onReady(youTubePlayer: YouTubePlayer) {
                                player = youTubePlayer
                                youTubePlayer.cueVideo(current.videoId, 0f)
                            }

                            override fun onStateChange(youTubePlayer: YouTubePlayer, state: PlayerConstants.PlayerState) {
                                playing = state == PlayerConstants.PlayerState.PLAYING ||
                                    state == PlayerConstants.PlayerState.BUFFERING
                                if (playing) meter.start() else meter.stop()
                            }
                        })
                    }
                }
            )
        }
        Text(current.title, style = H2.copy(fontSize = 21.sp), modifier = Modifier.padding(top = 14.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
            Text(catOf(current.cat).label, style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = C.Green),
                modifier = Modifier.background(Color.White, RoundedCornerShape(11.dp)).padding(horizontal = 9.dp, vertical = 3.dp))
            Spacer(Modifier.width(8.dp))
            Text("youtube.com", style = Body.copy(fontSize = 12.sp))
        }
        BalloonButton("Sadece ses · az veri", Modifier.padding(top = 14.dp).fillMaxWidth(), height = 56.dp, onClick = {
            player?.pause()
            store.countHandoff()
            openInYouTubeMusic(ctx, current)
        })
        Row(
            Modifier.padding(top = 10.dp).fillMaxWidth().background(Color(0xB3FFFFFF), RoundedCornerShape(18.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(8.dp).background(C.Yellow, CircleShape))
            Spacer(Modifier.width(10.dp))
            Text("Bu oynatıcı videoyu da yükler. Mobil veride “Sadece ses”i tercih et.",
                style = Body.copy(fontSize = 12.sp), modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Text(formatMb(sessionBytes), style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = C.Green),
                modifier = Modifier.background(Color.White, RoundedCornerShape(13.dp)).padding(horizontal = 10.dp, vertical = 5.dp))
        }
        if (next.isNotEmpty()) {
            Text("${catOf(current.cat).label}'de sıradaki", style = Strong.copy(fontSize = 15.sp),
                modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                next.forEach { n ->
                    Row(
                        Modifier.fillMaxWidth().height(64.dp).shadow(4.dp, RoundedCornerShape(22.dp))
                            .background(Color.White, RoundedCornerShape(22.dp))
                            .clickable {
                                current = n
                                sessionBytes = 0
                                player?.loadVideo(n.videoId, 0f)
                            }
                            .padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PopIcon(catOf(n.cat).icon, 50.dp, 46.dp, 54.dp, corner = 14.dp)
                        Spacer(Modifier.width(12.dp))
                        Text(n.title, style = Strong.copy(fontSize = 13.5.sp), maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Text("▶", style = TextStyle(fontSize = 16.sp, color = C.Green))
                    }
                }
            }
        }
        Spacer(Modifier.height(30.dp))
    }
}
