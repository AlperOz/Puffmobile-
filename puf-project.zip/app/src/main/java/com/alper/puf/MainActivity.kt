package com.alper.puf

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    private lateinit var store: Store
    private var sharedText by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(applicationContext)
        handleShare(intent)
        setContent {
            PufTheme {
                var watching by remember { mutableStateOf<LinkItem?>(null) }
                val w = watching
                if (w == null) {
                    KoleksiyonScreen(
                        store = store,
                        shared = sharedText,
                        onSharedUsed = { sharedText = null },
                        onWatch = { watching = it }
                    )
                } else {
                    IzleScreen(store, w, onBack = { watching = null })
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { sharedText = it }
        }
    }
}
